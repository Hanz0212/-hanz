bool myAssert(bool b, int row, char errType);
void error_a(const string &input, int &i, string &value, int row);
bool error_b(string name, int row);
void error_i(Node *root);
void error_j(Node *root);
void error_k(Node *root);

set<pair<int, char>> errors;
