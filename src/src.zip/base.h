#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <map>
#include <set>
// #include <variant>
#include <optional>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <fstream>
#include <memory> 
using namespace std;
int DEBUG = 0;
int DEBUG2 = 0;
ofstream fout1("lexer.txt");
ofstream fout2("parser.txt");
ofstream fout3("symbol.txt");
// ofstream fout4("mid.ll");
ofstream fout4("llvm_ir.txt");
ofstream ferr("error.txt");
ifstream fin("testfile.txt");

#include "base_lexer_declare.h"
#include "base_syntax_declare.h"
#include "base_symbol_declare.h"
#include "base_cal_declare.h"
#include "base_mid_declare.h"
#include "base_error_declare.h"

#include "base_error.h"
#include "base_lexer.h"
#include "base_syntax.h"
#include "base_symbol.h"
#include "base_cal.h"
#include "base_mid.h"

#include "base_print.h"
#include "base_optimize_mid.h"
