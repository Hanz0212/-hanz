
    cal_symbols();